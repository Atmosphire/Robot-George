/*
 * capteur_lumiere.h
 *
 *  Created on: 14 nov. 2022
 *      Author: 35387315
 */

#ifndef CAPTEUR_LUMIERE_H_
#define CAPTEUR_LUMIERE_H_





#endif /* CAPTEUR_LUMIERE_H_ */


int init_lumiere_jour(int pinLumiere);
int detecte_sortie(const POURCENTAGE, float lumiereDuJour, int pinLumiere);
