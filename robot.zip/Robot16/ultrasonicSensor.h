
/*
 * ultrasonicSensor.h
 *
 *  Created on: 4 nov. 2022
 *      Author: 35387315
 */


void initUltrasonicSensor();
int isObstacle(int seuil);
